# choice_tree.py
# Görevler için özel, çok adımlı seçim akışları (choice tree)

from typing import Dict, Any
import random

from engine import detect_context, choose_stat_for_context, compute_item_bonus, gain_xp
from character import reset_buffs

# -----------------------------------------------------------
# CHOICE_TREES
#
# "SınıfAdı": {
#   görev_index: {   # DİKKAT: görev_index = 0 ilk görev, 5 = 6. görev
#       "steps": [
#           {
#               "prompt": "Soru / sahne metni",
#               "options": [
#                   {"text": "Seçenek 1", "bonus": 2},
#                   {"text": "Seçenek 2", "bonus": 1},
#                   {"text": "Seçenek 3", "bonus": 0},
#               ]
#           },
#           ...
#       ]
#   }
# }
# -----------------------------------------------------------

CHOICE_TREES: Dict[str, Dict[int, Dict[str, Any]]] = {

    # ---------------------------------------------------
    # SAVAŞÇI – Görev 1 (index 0) ve Görev 6 (index 5)
    # ---------------------------------------------------
    "Savaşçı": {
        0: {
            "steps": [
                {
                    "prompt": "Titreyen savaş alanına ilk adımını attığında, havada eski savaşın yankısı var. "
                              "Önce neye odaklanırsın?",
                    "options": [
                        {
                            "text": "Dizini toprağa dayayıp sarsıntının yönünü, şiddetini ve ritmini anlamaya çalışırsın.",
                            "bonus": 2,
                        },
                        {
                            "text": "Etrafındaki kılıç ve zırh kalıntılarına bakıp, titremenin yaratık mı yoksa mühür mü kaynaklı olduğunu tahmin etmeye çalışırsın.",
                            "bonus": 1,
                        },
                        {
                            "text": "Hiç oyalanmadan içgüdülerine güvenir, seni en çok tedirgin eden yöne doğru ilerlersin.",
                            "bonus": 0,
                        },
                    ],
                },
                {
                    "prompt": "Sarsıntının merkezine yaklaştıkça çatlaklar birleşiyor. Son hamleni nasıl yaparsın?",
                    "options": [
                        {
                            "text": "Kalkanını yere sabitleyip kısa, kontrollü adımlarla çatlakların birleştiği noktayı test edersin.",
                            "bonus": 2,
                        },
                        {
                            "text": "Çatlak çizgilerinin yönünü takip ederek, hepsinin kestiği merkez noktayı kafanda işaretlersin.",
                            "bonus": 1,
                        },
                        {
                            "text": "Geri çekilme payı bırakarak yan adımlarla daire çizip hem mesafeyi hem hâkimiyeti korursun.",
                            "bonus": 0,
                        },
                    ],
                },
            ]
        },
        5: {
            "steps": [
                {
                    "prompt": "Savaş ruhu tamamen uyanmış; gökyüzü kızıl. İlk hamleni nasıl planlarsın?",
                    "options": [
                        {
                            "text": "Ruhun hareketlerini birkaç an izleyip, saldırı ile savunma arasındaki zayıf ritmi yakalamaya çalışırsın.",
                            "bonus": 2,
                        },
                        {
                            "text": "Kendi savaş tecrübelerini düşünerek ruhun en öngörülebilir saldırı açısını tahmin edersin.",
                            "bonus": 1,
                        },
                        {
                            "text": "Uzaktan daireler çizerek ruhun sana ne kadar yakınlaşmasına izin vereceğini sınarsın.",
                            "bonus": 0,
                        },
                    ],
                },
                {
                    "prompt": "Ruh sana doğru atıldığında karar anı gelir. Son hamleni nasıl yaparsın?",
                    "options": [
                        {
                            "text": "Doğru anı yakalayıp, ruhun gövdesine değil tam merkezindeki enerji düğümüne nişan alırsın.",
                            "bonus": 2,
                        },
                        {
                            "text": "Kalkanını güç merkezi ile arana sokup darbeyi yönlendirmeye çalışırsın.",
                            "bonus": 1,
                        },
                        {
                            "text": "Ani bir geri çekilişle ruhun momentumu ile dengesini bozmayı denersin.",
                            "bonus": 0,
                        },
                    ],
                },
            ]
        },
    },

    # ---------------------------------------------------
    # KAŞİF – 1 & 6
    # ---------------------------------------------------
    "Kaşif": {
        0: {
            "steps": [
                {
                    "prompt": "Yırtılmış haritanın tek parçası elinde. İlk bakışta neye dikkat edersin?",
                    "options": [
                        {
                            "text": "Sembolün etrafındaki küçük çiziklere ve koordinat olabilecek işaretlere odaklanırsın.",
                            "bonus": 2,
                        },
                        {
                            "text": "Kağıdın yırtık kenarlarının yönüne bakarak eksik parçanın nereye ait olabileceğini tahmin edersin.",
                            "bonus": 1,
                        },
                        {
                            "text": "Haritayı farklı açılardan ışığa tutup gizli bir mürekkep izi var mı diye kontrol edersin.",
                            "bonus": 0,
                        },
                    ],
                },
                {
                    "prompt": "Haritanın bir geçide işaret ettiğini hissediyorsun. İlk adımı nasıl atarsın?",
                    "options": [
                        {
                            "text": "Haritayı çevredeki ağaç ve kaya dizilimiyle eşleştirip, doğal konturlara göre yön tayin edersin.",
                            "bonus": 2,
                        },
                        {
                            "text": "Önce güvenli bir rota oluşturmak için yüksek bir noktadan çevreyi izleyeceğin bir yer ararsın.",
                            "bonus": 1,
                        },
                        {
                            "text": "Deneme amaçlı kısa bir keşif turu yapıp, dönüp haritayı tekrar değerlendirirsin.",
                            "bonus": 0,
                        },
                    ],
                },
            ]
        },
        5: {
            "steps": [
                {
                    "prompt": "Elarion’un Kayıp Yolu açılmak üzere. Topladığın parçaları birleştirmeden önce ne yaparsın?",
                    "options": [
                        {
                            "text": "Her parçadaki sembollerin yönünü ve hizasını tek tek kontrol edip yanlış bir birleşme riskini azaltırsın.",
                            "bonus": 2,
                        },
                        {
                            "text": "Yolun açılması halinde oluşabilecek riskleri kafanda sıraya koyup, geri dönüş planı hazırlarsın.",
                            "bonus": 1,
                        },
                        {
                            "text": "Etrafı hızla tarayıp dışarıdan gelecek bir müdahale olup olmadığını anlamaya çalışırsın.",
                            "bonus": 0,
                        },
                    ],
                },
                {
                    "prompt": "Yol açıldığında nasıl ilerleyeceğine karar vermelisin.",
                    "options": [
                        {
                            "text": "İlk olarak kısa bir mesafeyi keşfedip, geri dönerek yolun yapısını zihnine kazırsın.",
                            "bonus": 2,
                        },
                        {
                            "text": "Yol boyunca belirgin işaretler bırakarak geri dönüş rotanı garantilersin.",
                            "bonus": 1,
                        },
                        {
                            "text": "Risk alıp yolu mümkün olduğunca hızlı kat ederek önce neyle karşı karşıya olduğunu görmek istersin.",
                            "bonus": 0,
                        },
                    ],
                },
            ]
        },
    },

    # ---------------------------------------------------
    # BİLGİN – 1 & 6
    # ---------------------------------------------------
    "Bilgin": {
        0: {
            "steps": [
                {
                    "prompt": "Parşömen kendi kendine açıldı ve semboller parladı. İlk incelemen ne olur?",
                    "options": [
                        {
                            "text": "Semboller arasındaki tekrar eden desenleri bulup, olası bir alfabe veya sayı sistemi ararsın.",
                            "bonus": 2,
                        },
                        {
                            "text": "Satır boşluklarına ve hizaya bakarak metnin şiir, dua veya kayıt olup olmadığını anlamaya çalışırsın.",
                            "bonus": 1,
                        },
                        {
                            "text": "Parşömenin dokusunu inceleyip, hangi döneme ait olabileceğini kabaca tahmin etmeye çalışırsın.",
                            "bonus": 0,
                        },
                    ],
                },
                {
                    "prompt": "Bazı semboller sana tanıdık gelmeye başladı. Bir sonraki adımın ne olur?",
                    "options": [
                        {
                            "text": "Daha önce gördüğün dillerden örnekleri zihninde canlandırıp, benzer kökleri eşleştirmeye çalışırsın.",
                            "bonus": 2,
                        },
                        {
                            "text": "Belirgin sembolleri bir kenara not edip, bunların cümle başı veya özel isim olup olmadığını sorgularsın.",
                            "bonus": 1,
                        },
                        {
                            "text": "Henüz emin olmadığın kısımları işaretleyip, parşömeni başka metinlerle kıyaslamayı planlarsın.",
                            "bonus": 0,
                        },
                    ],
                },
            ]
        },
        5: {
            "steps": [
                {
                    "prompt": "Taş küre sembolleri etrafında döndürerek sana son bir bilmece soruyor. Önce ne yaparsın?",
                    "options": [
                        {
                            "text": "Sembollerin dönüş sırasını dikkatle takip edip, tekrar eden döngüleri fark etmeye çalışırsın.",
                            "bonus": 2,
                        },
                        {
                            "text": "Sembol gruplarının durduğu anları zihninde fotoğraf gibi kaydedersin.",
                            "bonus": 1,
                        },
                        {
                            "text": "Küre dönerken ses, titreşim veya ışıkta bir değişiklik olup olmadığına odaklanırsın.",
                            "bonus": 0,
                        },
                    ],
                },
                {
                    "prompt": "Bilmecenin anlamı yavaş yavaş şekilleniyor. Son çözüm hamlen nedir?",
                    "options": [
                        {
                            "text": "Anlam bütünlüğünü bozan sembolleri elersin ve kalanlara göre son anlamı kurarsın.",
                            "bonus": 2,
                        },
                        {
                            "text": "Kürenin sana sorduğu soruyu, yüksek sesle kendi cümlelerinle tekrar edip cevabını da aynı netlikte verirsin.",
                            "bonus": 1,
                        },
                        {
                            "text": "Cevabın sadece bilgi değil, niyet içerdiğini bilerek dürüst ama stratejik bir yanıt seçersin.",
                            "bonus": 0,
                        },
                    ],
                },
            ]
        },
    },

    # ---------------------------------------------------
    # KEHANETÇİ – 1 & 6
    # ---------------------------------------------------
    "Kehanetçi": {
        0: {
            "steps": [
                {
                    "prompt": "Rüzgar sana kendi sesinde fısıldadı. Bu anı nasıl karşılıyorsun?",
                    "options": [
                        {
                            "text": "Gözlerini kapatıp rüzgarın yönünü, hızını ve taşıdığı yankıları tek tek ayırt etmeye çalışırsın.",
                            "bonus": 2,
                        },
                        {
                            "text": "Fısıltının tekrar edip etmediğini dinleyip, belirgin kelimeleri seçmeye çalışırsın.",
                            "bonus": 1,
                        },
                        {
                            "text": "İlk anı fazla ciddiye almadan, bunun bir uyarı mı yoksa çağrı mı olduğuna karar vermek için biraz beklersin.",
                            "bonus": 0,
                        },
                    ],
                },
                {
                    "prompt": "Fısıltının yönü artık daha belirgin. Son kararın ne olur?",
                    "options": [
                        {
                            "text": "Direkt o yöne doğru yürüyerek mesajı kaynağında karşılamayı seçersin.",
                            "bonus": 2,
                        },
                        {
                            "text": "Yolda ruhların veya işaretlerin eşlik edip etmediğini görmek için çevreyi dikkatle gözlersin.",
                            "bonus": 1,
                        },
                        {
                            "text": "Önce güvenli bir mesafe belirleyip, fısıltıyı oradan takip edersin.",
                            "bonus": 0,
                        },
                    ],
                },
            ]
        },
        5: {
            "steps": [
                {
                    "prompt": "Gelecekteki benliğinin sesi, zamanın ipliğini kesmekten bahsediyor. Bu anı nasıl yorumlarsın?",
                    "options": [
                        {
                            "text": "Zaman döngüsünün sana gösterdiği tekrar eden hataları ve başarısızlıkları zihninde bir tabloya yerleştirirsin.",
                            "bonus": 2,
                        },
                        {
                            "text": "Sana anlatılan kader ile kendi seçtiğin yol arasındaki farkları ayırt etmeye çalışırsın.",
                            "bonus": 1,
                        },
                        {
                            "text": "Bu sesi tamamen onaylamadan önce, içgüdülerinin ona güvenip güvenmediğini yoklarsın.",
                            "bonus": 0,
                        },
                    ],
                },
                {
                    "prompt": "Döngüyü kırmak için son bir seçim yapmalısın. Nasıl hareket edersin?",
                    "options": [
                        {
                            "text": "Kendi iradeni merkeze alır, kehanetin işaret ettiği yolu değil, anın sana doğru hissettirdiği yolu seçersin.",
                            "bonus": 2,
                        },
                        {
                            "text": "Gelecekteki benliğinin uyarılarını dikkate alır, ama önemli detaylarda ufak değişiklikler yaparak yeni bir rota çizersin.",
                            "bonus": 1,
                        },
                        {
                            "text": "Hiçbir tarafı tamamen reddetmeden, döngüyü yumuşak bir geçişle bozacak bir orta yol ararsın.",
                            "bonus": 0,
                        },
                    ],
                },
            ]
        },
    },

    # ---------------------------------------------------
    # CASUS – 1 & 6
    # ---------------------------------------------------
    "Casus": {
        0: {
            "steps": [
                {
                    "prompt": "Duvara düşen gölge, sahibinden bağımsız hareket ediyor gibi. İlk hamlen nedir?",
                    "options": [
                        {
                            "text": "Işığın geliş açısını ve gölgenin yönünü hesaplayıp, bu yansımayı yaratabilecek noktaları zihninde işaretlersin.",
                            "bonus": 2,
                        },
                        {
                            "text": "Gölgenin kaybolduğu ana odaklanır, o sırada fiziki bir hareket olup olmadığını hatırlamaya çalışırsın.",
                            "bonus": 1,
                        },
                        {
                            "text": "Bir süre hiç hareket etmeden, gölgenin seni nasıl ‘gözetlediğini’ anlamaya çalışırsın.",
                            "bonus": 0,
                        },
                    ],
                },
                {
                    "prompt": "Gölgenin seni bir yere yönlendirdiğini fark ettin. Nasıl takip edersin?",
                    "options": [
                        {
                            "text": "Doğrudan gölgenin gösterdiği hatta ilerlemek yerine, bir miktar yan açıdan paralel bir rota çizersin.",
                            "bonus": 2,
                        },
                        {
                            "text": "Arada durup arkana bakarak, takip edilip edilmediğini kontrol edersin.",
                            "bonus": 1,
                        },
                        {
                            "text": "Sanki hiçbir şey fark etmemiş gibi, sıradan adımlarla ama dikkatle ilerlersin.",
                            "bonus": 0,
                        },
                    ],
                },
            ]
        },
        5: {
            "steps": [
                {
                    "prompt": "Gölgelerdeki Ağ’ın merkezine ulaştın. Masada haritalar ve işaretler var. İlk neyi okursun?",
                    "options": [
                        {
                            "text": "Haritalardaki siyah işaretlerin dizilişini inceleyip, ağın düğüm noktalarını tek tek tespit edersin.",
                            "bonus": 2,
                        },
                        {
                            "text": "Masadaki notlarda kullanılan dil ve sembollerden yazanın kim olduğunu tahmin etmeye çalışırsın.",
                            "bonus": 1,
                        },
                        {
                            "text": "Önce kaçış yollarının işaretlenmiş olup olmadığına bakarak, tuzak ihtimalini hesaplarsın.",
                            "bonus": 0,
                        },
                    ],
                },
                {
                    "prompt": "Ağın lideri seni bekliyor olabilir. Son yaklaşımını nasıl yaparsın?",
                    "options": [
                        {
                            "text": "Gizlendiğin yerden, liderin reflekslerini ve dikkat dağınıklığını ölçmek için kısa bir süre daha beklersin.",
                            "bonus": 2,
                        },
                        {
                            "text": "Kendini açık etmek yerine, önce sesini veya gölgeni kullanarak tepkisini test edersin.",
                            "bonus": 1,
                        },
                        {
                            "text": "Normal bir görüşme talebiyle ortaya çıkıp, bilgi toplamak için diyaloğa oynamayı seçersin.",
                            "bonus": 0,
                        },
                    ],
                },
            ]
        },
    },

    # ---------------------------------------------------
    # SUİKASTÇI – 1 & 6
    # ---------------------------------------------------
    "Suikastçı": {
        0: {
            "steps": [
                {
                    "prompt": "Duvara yansıyan gölge, sahibinden bağımsız kayıyor. Bu işin kokusunu alıyorsun. İlk tepkin?",
                    "options": [
                        {
                            "text": "Işık kaynaklarının yerini ve güçlerini gözden geçirip, bu yansımayı bilinçli yaratabilecek konumları hesap edersin.",
                            "bonus": 2,
                        },
                        {
                            "text": "Gölgenin hareket ettiği yöne paralel ama daha karanlık bir rota bulmaya çalışırsın.",
                            "bonus": 1,
                        },
                        {
                            "text": "Hiç panik yapmadan kendi gölgeni de kullanarak sahte bir iz bırakmaya hazırlanırsın.",
                            "bonus": 0,
                        },
                    ],
                },
                {
                    "prompt": "Gölge kayboluyor. Peşinden gitmek istiyorsun. Nasıl ilerlersin?",
                    "options": [
                        {
                            "text": "Adımlarını zemine en az ses çıkaracak yere basarak, ‘sessiz adım’ tekniğini kullanırsın.",
                            "bonus": 2,
                        },
                        {
                            "text": "Köşe dönüşlerinde kısa süre durup, nefes alıp vermeni bile yavaşlatırsın.",
                            "bonus": 1,
                        },
                        {
                            "text": "Olası saldırı durumunda hızla geri çekilebileceğin, açık bir kaçış rotası bırakırsın.",
                            "bonus": 0,
                        },
                    ],
                },
            ]
        },
        5: {
            "steps": [
                {
                    "prompt": "İzlerin hepsi seni gösteriyor; kullandığın teknikler, işaretler… Gerçek Sessiz Adım’ın sen olabileceği gerçeğiyle yüzleşiyorsun.",
                    "options": [
                        {
                            "text": "Geçmişte sana öğretilen yöntemleri tek tek hatırlayıp, bu izlerin hangi eğitim anına benzetilebileceğini düşünürsün.",
                            "bonus": 2,
                        },
                        {
                            "text": "Bu izleri kimin taklit edebileceğini ve kimlerin senin kadar detay bilebileceğini sorgularsın.",
                            "bonus": 1,
                        },
                        {
                            "text": "Önce duygusal tepkiyi bastırıp, durumu tamamen teknik açıdan incelemeye karar verirsin.",
                            "bonus": 0,
                        },
                    ],
                },
                {
                    "prompt": "Karar zamanı: Gölgelerin ardındaki gerçeği açığa çıkarırken nasıl davranacaksın?",
                    "options": [
                        {
                            "text": "Kendini yem olarak kullanır, sahte bir zayıflık göstererek gerçek saldırganı sahneye çekmeye çalışırsın.",
                            "bonus": 2,
                        },
                        {
                            "text": "İzleri izleyen başka izler var mı diye bakarak, perde arkasındaki ikinci kişiyi bulmaya odaklanırsın.",
                            "bonus": 1,
                        },
                        {
                            "text": "Doğrudan çatışma yerine, bilgiyi ele geçirip gölgede kalmayı tercih edersin.",
                            "bonus": 0,
                        },
                    ],
                },
            ]
        },
    },

    # ---------------------------------------------------
    # ŞİFACI – 1 & 6
    # ---------------------------------------------------
    "Şifacı": {
        0: {
            "steps": [
                {
                    "prompt": "Ormanın girişindeki ağaç canlı ama acı çekiyor. İlk tanın ne olur?",
                    "options": [
                        {
                            "text": "Kabuğuna elini koyup, içerden gelen öz akışını ve titreşimini hissetmeye çalışırsın.",
                            "bonus": 2,
                        },
                        {
                            "text": "Köklerin etrafındaki toprağı inceleyip, zehir veya kuruma belirtisi ararsın.",
                            "bonus": 1,
                        },
                        {
                            "text": "Yaprakların rengine ve düşüş biçimine bakarak, hangi tür dengesizlikten etkilendiğini tahmin edersin.",
                            "bonus": 0,
                        },
                    ],
                },
                {
                    "prompt": "Ağacın acısının sadece fiziksel olmadığını hissediyorsun. Ardından ne yaparsın?",
                    "options": [
                        {
                            "text": "Kısa bir ritüel nefesiyle kendi enerjini dengeleyip, ağacın ruhuna sakin bir niyet gönderirsin.",
                            "bonus": 2,
                        },
                        {
                            "text": "Ağacın etrafındaki diğer bitkilere de bakarak, sorunun bölgesel mi yoksa sadece ona özel mi olduğunu anlamaya çalışırsın.",
                            "bonus": 1,
                        },
                        {
                            "text": "Bu ağacı işaretleyip, ileride dönüp daha kapsamlı bir şifa ritüeli yapmayı planlarsın.",
                            "bonus": 0,
                        },
                    ],
                },
            ]
        },
        5: {
            "steps": [
                {
                    "prompt": "Ormanın ruhunun kalbine ulaştın. Görünmeyen bir yara bütün dengeyi bozuyor. İlk şifa adımın?",
                    "options": [
                        {
                            "text": "Orman Özü, Denge Taşı ve Ruh İpliğini bir araya getirerek aralarında akış kurulmasını sağlarsın.",
                            "bonus": 2,
                        },
                        {
                            "text": "Önce hangi yaranın öncelikli olduğunu hissedip, en kritik noktaya odaklanırsın.",
                            "bonus": 1,
                        },
                        {
                            "text": "Çevredeki sessizliği dinleyerek, ormanın hangi tonda bir sesle ‘yakardığını’ anlamaya çalışırsın.",
                            "bonus": 0,
                        },
                    ],
                },
                {
                    "prompt": "Ruhun sana verdiği son tepkiyi hissediyorsun. Şifa ritüelini nasıl tamamlarsın?",
                    "options": [
                        {
                            "text": "Tüm enerjiyi tek bir noktaya değil, dalgalar halinde ormanın her katmanına yayacak bir niyetle bitirirsin.",
                            "bonus": 2,
                        },
                        {
                            "text": "Zayıf noktaları mühürleyip, gelecekte tekrar açılmaması için küçük koruma işaretleri bırakırsın.",
                            "bonus": 1,
                        },
                        {
                            "text": "Ruhun sana teşekkür edip etmediğini anlamaya çalışarak yavaşça çekilirsin.",
                            "bonus": 0,
                        },
                    ],
                },
            ]
        },
    },

    # ---------------------------------------------------
    # KOMUTAN – 1 & 6
    # ---------------------------------------------------
    "Komutan": {
        0: {
            "steps": [
                {
                    "prompt": "Terk edilmiş siperlerde taze izler var. Birileri yakın zamanda buradaymış. İlk değerlendirmem?",
                    "options": [
                        {
                            "text": "Siperlerin yerleşimini bir taktikçi gözüyle inceler, savunma ve saldırı hattını kafanda çizersin.",
                            "bonus": 2,
                        },
                        {
                            "text": "Topraktaki ayak izlerinin yönüne göre birliklerin giriş-çıkış düzenini tahmin edersin.",
                            "bonus": 1,
                        },
                        {
                            "text": "Silah, kalkan ve zırh kalıntılarını sayarak buradan geçen grubun büyüklüğünü hesaplamaya çalışırsın.",
                            "bonus": 0,
                        },
                    ],
                },
                {
                    "prompt": "Bu izlerin bir hazırlık mı yoksa geri çekilme mi olduğunu anlaman gerek. Nasıl karar verirsin?",
                    "options": [
                        {
                            "text": "İzlerin geliş ve gidiş yoğunluğunu kıyaslayıp net bir yön üstünlüğü ararsın.",
                            "bonus": 2,
                        },
                        {
                            "text": "Siperlerin hangi tarafının güçlendirildiğine bakarak savunma mı yoksa pusu mu hazırlandığını analiz edersin.",
                            "bonus": 1,
                        },
                        {
                            "text": "Küçük bir bölgede numune alır gibi detaylı inceleme yapıp, geneli buna göre yorumlarsın.",
                            "bonus": 0,
                        },
                    ],
                },
            ]
        },
        5: {
            "steps": [
                {
                    "prompt": "Kül Krallığı’nın dönüşünü müjdeleyen mühür neredeyse tamam. Son karar savaş veya barış için belirleyici olabilir.",
                    "options": [
                        {
                            "text": "Mührün tamamlanması halinde hangi cephelerin ilk çökeceğini hesaplayarak risk haritası çıkartırsın.",
                            "bonus": 2,
                        },
                        {
                            "text": "Mührü tamamlayan ritüelin liderini ve zayıf anını bulmaya odaklanırsın.",
                            "bonus": 1,
                        },
                        {
                            "text": "Kendi birliklerinin moral ve hazırlık seviyesini aklından geçirerek en gerçekçi senaryoya hazırlanırsın.",
                            "bonus": 0,
                        },
                    ],
                },
                {
                    "prompt": "Müdahale anı geldi. Son hamleni nasıl planlarsın?",
                    "options": [
                        {
                            "text": "Ritüeli bozan ani ama hedefe yönelik bir manevra tasarlar, en kritik noktaya yönelirsin.",
                            "bonus": 2,
                        },
                        {
                            "text": "Dikkat dağıtıcı bir hamle ile ritüel grubunu ikiye bölüp koordinasyonu bozmayı denersin.",
                            "bonus": 1,
                        },
                        {
                            "text": "Mührü tamamen yok etmek yerine, onu kontrol edebileceğin bir seviyede zayıflatmayı hedeflersin.",
                            "bonus": 0,
                        },
                    ],
                },
            ]
        },
    },

    # ---------------------------------------------------
    # MUCİT – 1 & 6
    # ---------------------------------------------------
    "Mucit": {
        0: {
            "steps": [
                {
                    "prompt": "Terk edilmiş işlikte tek bir çark kendi kendine dönüyor. İlk neyi incelersin?",
                    "options": [
                        {
                            "text": "Çarkın bağlı olduğu mil ve dişlileri takip ederek hangi parçalara güç aktarıldığını anlamaya çalışırsın.",
                            "bonus": 2,
                        },
                        {
                            "text": "Çarkın dönme hızına, sesine ve titreşimine bakarak doğal mı yoksa büyüsel mi olduğunu tahmin edersin.",
                            "bonus": 1,
                        },
                        {
                            "text": "Çarkın çevresine bakıp, eski ustaların bıraktığı not veya işaret ararsın.",
                            "bonus": 0,
                        },
                    ],
                },
                {
                    "prompt": "Bu çarkın tek başına çalışamayacağını biliyorsun. Sıradaki hamlen nedir?",
                    "options": [
                        {
                            "text": "Çarkı durdurmadan önce, sistemin geri kalanının tepki verip vermediğini test edecek küçük müdahaleler yaparsın.",
                            "bonus": 2,
                        },
                        {
                            "text": "Çarkı hafifçe yavaşlatıp hızlandırarak ritim değişiminde ortaya çıkan gizli sesi dinlersin.",
                            "bonus": 1,
                        },
                        {
                            "text": "Çarkı bir süre daha gözlemleyip, toz izlerinden geçmiş hareketini analiz etmeye çalışırsın.",
                            "bonus": 0,
                        },
                    ],
                },
            ]
        },
        5: {
            "steps": [
                {
                    "prompt": "Elarion’un Ana Mekanizması tüm parçalarıyla karşında. Son birleşim öncesi ne yaparsın?",
                    "options": [
                        {
                            "text": "Her parçanın yuvasını tek tek kontrol eder, yanlış bir yerleştirmenin yaratacağı zincirleme hasarı hesap edersin.",
                            "bonus": 2,
                        },
                        {
                            "text": "Sigorta görevi gören parçaları ayrı bir gözle kontrol ederek, aşırı yük durumunda nasıl davranacaklarını analiz edersin.",
                            "bonus": 1,
                        },
                        {
                            "text": "Mekanizmanın genel tasarımına bakıp, kurucunun niyetini anlamaya çalışırsın.",
                            "bonus": 0,
                        },
                    ],
                },
                {
                    "prompt": "Mekanizma çalışmaya hazır. Çalıştırma anını nasıl yönetirsin?",
                    "options": [
                        {
                            "text": "Önce kısmi bir aktivasyon yaparak mekanizmayı düşük güçte test edersin.",
                            "bonus": 2,
                        },
                        {
                            "text": "Tüm parametreleri zihninde tekrar ettikten sonra kontrollü ama tam bir aktivasyon uygularsın.",
                            "bonus": 1,
                        },
                        {
                            "text": "Çalışma sırasında olası arızalar için müdahale edebileceğin noktaları yakınına alırsın.",
                            "bonus": 0,
                        },
                    ],
                },
            ]
        },
    },

    # ---------------------------------------------------
    # DİPLOMAT – 1 & 6
    # ---------------------------------------------------
    "Diplomat": {
        0: {
            "steps": [
                {
                    "prompt": "Yırtılmış bir antlaşma metni buldun. İlk bakışta neye odaklanırsın?",
                    "options": [
                        {
                            "text": "Metinde geçen taraf isimlerini ve unvanları bularak, antlaşmanın kimler arasında yapıldığını anlamaya çalışırsın.",
                            "bonus": 2,
                        },
                        {
                            "text": "Yırtık kısımların neleri saklıyor olabileceğini, cümle akışından tahmin etmeye çalışırsın.",
                            "bonus": 1,
                        },
                        {
                            "text": "Mührün yarım kalmış kısmına bakarak hangi otoriteyi temsil ettiğini kestirmeye çalışırsın.",
                            "bonus": 0,
                        },
                    ],
                },
                {
                    "prompt": "Antlaşmanın tehlikeye girdiğini hissediyorsun. Sonraki adımın ne olur?",
                    "options": [
                        {
                            "text": "Kalan metni tarafsız bir gözle okuyup, her iki taraf için de riskli olabilecek maddeleri işaretlersin.",
                            "bonus": 2,
                        },
                        {
                            "text": "Bu antlaşmadan kimin en çok fayda sağladığını hesaplayarak olası sabotajı kimin yapmak isteyebileceğini düşünürsün.",
                            "bonus": 1,
                        },
                        {
                            "text": "Önce olayı büyütmeden, antlaşmayı sessizce eski haline getirmeyi planlarsın.",
                            "bonus": 0,
                        },
                    ],
                },
            ]
        },
        5: {
            "steps": [
                {
                    "prompt": "Taraflar karşı karşıya gelmek üzere; savaş ya da barış senin kelimelerine bakıyor.",
                    "options": [
                        {
                            "text": "Her iki tarafın da en büyük korkularını ve kayıplarını gözeten ortak bir zemin kurarsın.",
                            "bonus": 2,
                        },
                        {
                            "text": "Antlaşmanın manipüle edilmiş kısmını delil olarak sunup, asıl düşmanın yanlış bilgi olduğunu gösterirsin.",
                            "bonus": 1,
                        },
                        {
                            "text": "İlk anda tansiyonu düşürecek yumuşak ama kararlı bir giriş yaparsın.",
                            "bonus": 0,
                        },
                    ],
                },
                {
                    "prompt": "Son cümlelerin kalpleri ve akılları şekillendirecek. Nasıl bitirirsin?",
                    "options": [
                        {
                            "text": "Her iki tarafa da, barışın onlara sağlayacağı somut kazançları net bir dille hatırlatırsın.",
                            "bonus": 2,
                        },
                        {
                            "text": "Geçmişte yaşanmış yıkıcı bir savaşı örnek verip, aynı hatayı tekrarlamamalarını istersin.",
                            "bonus": 1,
                        },
                        {
                            "text": "Bu kararın sadece bugün için değil, gelecek nesiller için de verildiğini vurgularsın.",
                            "bonus": 0,
                        },
                    ],
                },
            ]
        },
    },

    # ---------------------------------------------------
    # ŞÖVALYE – 1 & 6
    # ---------------------------------------------------
    "Şövalye": {
        0: {
            "steps": [
                {
                    "prompt": "Eski kralın kalkanı kırılmış halde yerde duruyor. Bu manzara onuruna dokunuyor. İlk incelemen?",
                    "options": [
                        {
                            "text": "Kalkanın darbe aldığı noktaları inceler, tek güçlü bir darbe mi yoksa çoklu saldırı mı olduğunu anlamaya çalışırsın.",
                            "bonus": 2,
                        },
                        {
                            "text": "Kalkanın arkasındaki kayışlara ve tutuş izlerine bakarak, sahibinin son anda ne yaptığını tahmin edersin.",
                            "bonus": 1,
                        },
                        {
                            "text": "Çevredeki zemin izlerine bakarak, burada yaşanan çatışmanın yönünü ve süresini tahmin edersin.",
                            "bonus": 0,
                        },
                    ],
                },
                {
                    "prompt": "Bu kırık kalkanın bir yeminle bağlantılı olduğunu hissediyorsun. Ardından ne yaparsın?",
                    "options": [
                        {
                            "text": "Kalkanı eski efsanelerdeki anlatılarla karşılaştırıp, hangi yemini temsil ettiğini bulmaya çalışırsın.",
                            "bonus": 2,
                        },
                        {
                            "text": "Yemin bozulduğunda nelerin sarsılacağını düşünerek, olayın ciddiyetini zihninde tartarsın.",
                            "bonus": 1,
                        },
                        {
                            "text": "Kalkanı güvenli bir yere kaldırmayı ve daha sonra ritüel bir onarım için hazırlamayı planlarsın.",
                            "bonus": 0,
                        },
                    ],
                },
            ]
        },
        5: {
            "steps": [
                {
                    "prompt": "Kırık yemin, kalkan, asa ve mühür yeniden bir araya gelmek üzere. Şövalye düzeninin kaderi masada.",
                    "options": [
                        {
                            "text": "Yeminin şartlarını bir bir hatırlayıp, hangi ruh haliyle tekrar edilmesi gerektiğini zihninde canlandırırsın.",
                            "bonus": 2,
                        },
                        {
                            "text": "Düzenin hangi kısmının en çok zarar gördüğünü tespit ederek, oraya ekstra dikkat göstermeye karar verirsin.",
                            "bonus": 1,
                        },
                        {
                            "text": "Yemin yenilenirken, dışarıdan gelecek olası bir sabotaja karşı çevreyi de gözlersin.",
                            "bonus": 0,
                        },
                    ],
                },
                {
                    "prompt": "Onur yemini tekrar edilirken son hareketini nasıl belirlersin?",
                    "options": [
                        {
                            "text": "Kılıcını yere değil göğe kaldırarak, yemini sadece krala değil, toprağa ve halka da adarsın.",
                            "bonus": 2,
                        },
                        {
                            "text": "Eski sözlere küçük ama anlamlı bir eklenti yaparak, yeni dönemin sorumluluğunu üstlenirsin.",
                            "bonus": 1,
                        },
                        {
                            "text": "Sessizce yemin eder, sözlerinden çok duruşunun konuşmasına izin verirsin.",
                            "bonus": 0,
                        },
                    ],
                },
            ]
        },
    },

    # ---------------------------------------------------
    # MUHAFIZ – 1 & 6
    # ---------------------------------------------------
    "Muhafız": {
        0: {
            "steps": [
                {
                    "prompt": "Tapınak kapısı gece kendi kendine titredi. Bir muhafız için bu kabul edilemez. Önce ne yaparsın?",
                    "options": [
                        {
                            "text": "Kapının menteşe ve kilit noktalarını tek tek kontrol ederek, dışarıdan bir zorlama izi ararsın.",
                            "bonus": 2,
                        },
                        {
                            "text": "Kapının etrafındaki duvarda çatlak, oyuk veya yeni izler olup olmadığına bakarsın.",
                            "bonus": 1,
                        },
                        {
                            "text": "Kapının önünde bir süre bekleyerek, titremenin tekrar edip etmediğini gözlemlersin.",
                            "bonus": 0,
                        },
                    ],
                },
                {
                    "prompt": "Titremenin sadece fiziksel bir darbeden kaynaklanmadığını hissediyorsun. Sonraki adımın?",
                    "options": [
                        {
                            "text": "Kapının ardındaki alanı zihninde canlandırıp, içeriden gelen olası tehdit türlerini sıralarsın.",
                            "bonus": 2,
                        },
                        {
                            "text": "Nöbet çizelgelerini gözden geçirip, o saatlerde kapıya kimlerin yaklaşabileceğini kontrol edersin.",
                            "bonus": 1,
                        },
                        {
                            "text": "Her ihtimale karşı kapıyı geçici olarak güçlendirecek basit önlemler alırsın.",
                            "bonus": 0,
                        },
                    ],
                },
            ]
        },
        5: {
            "steps": [
                {
                    "prompt": "Kapının gerçek nöbetçisi olarak çağrılıyorsun. Geçitteki tehdit ile yüzleşmeden hemen önce ne yaparsın?",
                    "options": [
                        {
                            "text": "Zihninde bütün savunma noktalarını ve geri çekilme rotalarını netleştirirsin.",
                            "bonus": 2,
                        },
                        {
                            "text": "Kapının ardındaki varlığın motivasyonunu anlamaya çalışarak, sadece güç değil akıl da kullanmayı planlarsın.",
                            "bonus": 1,
                        },
                        {
                            "text": "Nöbet anlamını ve bugüne kadar korudukların her şeyi hatırlayıp, moralini sağlamlaştırırsın.",
                            "bonus": 0,
                        },
                    ],
                },
                {
                    "prompt": "Son nöbetini tutarken tehdidi durdurmak için nasıl hareket edersin?",
                    "options": [
                        {
                            "text": "Tehdidi kapıdan mümkün olduğunca uzakta karşılayarak, geçidi savaş alanına çevirmemeye çalışırsın.",
                            "bonus": 2,
                        },
                        {
                            "text": "Savunma ile hücumu dengede tutacak bir pozisyon seçip, rakibin sana göre hamle yapmasına izin vermezsin.",
                            "bonus": 1,
                        },
                        {
                            "text": "Gerekirse geçidi tamamen kapatacak son çareyi de aklında tutarak, esnek bir savaş planı uygularsın.",
                            "bonus": 0,
                        },
                    ],
                },
            ]
        },
    },

}


def _current_quest_index(character: Dict[str, Any]) -> int:
    """
    get_next_quest, görevi verirken karakter['görev_index'] değerini +1 arttırıyor.
    Biz tree'yi o AN oynattığımız görev için kullanacağız, yani index-1.
    """
    idx = character.get("görev_index", 0)
    if idx <= 0:
        return 0
    return idx - 1


def has_choice_tree(character: Dict[str, Any]) -> bool:
    """
    Karakterin mevcut görev index'i için tanımlı bir choice tree var mı?
    """
    cls = character.get("sınıf")
    idx = _current_quest_index(character)
    return cls in CHOICE_TREES and idx in CHOICE_TREES[cls]


def play_choice_tree(character: Dict[str, Any], quest_text: str) -> str:
    """
    Tanımlı bir choice tree varsa onu kullanarak görevi oynatır.
    Yoksa ValueError fırlatır (ana kodda yakalayıp engine.play_quest'e düşebilirsin).
    """
    cls = character.get("sınıf")
    idx = _current_quest_index(character)

    if cls not in CHOICE_TREES or idx not in CHOICE_TREES[cls]:
        raise ValueError("Bu görev için choice tree tanımlı değil.")

    tree = CHOICE_TREES[cls][idx]
    steps = tree["steps"]

    print("\n--- Görev ---\n")
    print(quest_text)
    input("\n➡ Devam etmek için Enter’a bas...\n")

    toplam_bonus = 0

    for step_no, step in enumerate(steps, start=1):
        print(f"\n--- Seçim {step_no} ---\n")
        print(step["prompt"])
        print()

        for i, opt in enumerate(step["options"], start=1):
            print(f"{i}) {opt['text']}")

        while True:
            try:
                secim = int(input("\nSeçimin (1-3): "))
                if secim in (1, 2, 3):
                    break
            except:
                pass
            print("Geçersiz seçim, tekrar dene.")

        chosen = step["options"][secim - 1]
        toplam_bonus += chosen["bonus"]
        print(f"\n→ {chosen['text']}\n")

    # Sonuç hesaplama (engine ile aynı mantık)
    context = detect_context(quest_text)
    chosen_stat = choose_stat_for_context(context)

    temel = character["statlar"][chosen_stat]
    buff = character["buff"][chosen_stat]
    item_bonus = compute_item_bonus(character, quest_text)
    rast = random.randint(-2, 3)

    toplam = temel + buff + toplam_bonus + item_bonus + rast

    print("------ SONUÇ ------")
    print(f"Kullanılan temel özellik: {chosen_stat} ({temel})")
    if buff:
        print(f"Geçici avantajın: +{buff}")
    print(f"Seçimlerinden gelen toplam etki: +{toplam_bonus}")
    if item_bonus > 0:
        print(f"Eşyaların gizli katkısı: +{item_bonus}")
    print(f"Kaderin dokunuşu: {rast:+}")
    print(f"TOPLAM: {toplam}\n")

    if toplam >= 15:
        print("🌟 EFSANE BİR BAŞARI! Yolun senin için açılıyor.")
        result = "efsane"
    elif toplam >= 10:
        print("✅ Başarılı! Zorlukları aşarak ilerliyorsun.")
        result = "başarılı"
    elif toplam >= 6:
        print("⚠️ Zorlandın ama pes etmiyorsun, yoluna devam ediyorsun.")
        result = "zor"
    else:
        print("❌ Bu sefer başaramadın… ama bu dünya ikinci şans tanır.")
        result = "başarısız"

    print()
    gain_xp(character, result)
    reset_buffs(character)

    return result
