import random
from datetime import date

# ===========================================
#   BURÇ → SINIF HARİTALANDIRMASI
# ===========================================

def get_burc(gun, ay):
    if (ay == 3 and gun >= 21) or (ay == 4 and gun <= 19): return "Koç"
    if (ay == 4 and gun >= 20) or (ay == 5 and gun <= 20): return "Boğa"
    if (ay == 5 and gun >= 21) or (ay == 6 and gun <= 20): return "İkizler"
    if (ay == 6 and gun >= 21) or (ay == 7 and gun <= 22): return "Yengeç"
    if (ay == 7 and gun >= 23) or (ay == 8 and gun <= 22): return "Aslan"
    if (ay == 8 and gun >= 23) or (ay == 9 and gun <= 22): return "Başak"
    if (ay == 9 and gun >= 23) or (ay == 10 and gun <= 22): return "Terazi"
    if (ay == 10 and gun >= 23) or (ay == 11 and gun <= 21): return "Akrep"
    if (ay == 11 and gun >= 22) or (ay == 12 and gun <= 21): return "Yay"
    if (ay == 12 and gun >= 22) or (ay == 1 and gun <= 19): return "Oğlak"
    if (ay == 1 and gun >= 20) or (ay == 2 and gun <= 18): return "Kova"
    return "Balık"

BURC_SINIF = {
    "Koç": "Savaşçı",
    "Boğa": "Şövalye",
    "İkizler": "Casus",
    "Yengeç": "Şifacı",
    "Aslan": "Komutan",
    "Başak": "Bilgin",
    "Terazi": "Diplomat",
    "Akrep": "Suikastçı",
    "Yay": "Kaşif",
    "Oğlak": "Muhafız",
    "Kova": "Mucit",
    "Balık": "Kehanetçi",
}

# ===========================================
#   TEMEL STATLAR
# ===========================================

BASE_STATS = {
    "Savaşçı":    {"güç": 8, "zeka": 4, "karizma": 4, "şans": 5},
    "Şövalye":    {"güç": 7, "zeka": 5, "karizma": 6, "şans": 4},
    "Casus":      {"güç": 4, "zeka": 7, "karizma": 6, "şans": 6},
    "Şifacı":     {"güç": 3, "zeka": 8, "karizma": 5, "şans": 6},
    "Komutan":    {"güç": 6, "zeka": 7, "karizma": 9, "şans": 4},
    "Bilgin":     {"güç": 2, "zeka": 9, "karizma": 5, "şans": 6},
    "Diplomat":   {"güç": 3, "zeka": 7, "karizma": 9, "şans": 5},
    "Suikastçı":  {"güç": 6, "zeka": 7, "karizma": 4, "şans": 8},
    "Kaşif":      {"güç": 5, "zeka": 6, "karizma": 6, "şans": 9},
    "Muhafız":    {"güç": 8, "zeka": 4, "karizma": 4, "şans": 5},
    "Mucit":      {"güç": 3, "zeka": 10, "karizma": 6, "şans": 5},
    "Kehanetçi":  {"güç": 2, "zeka": 9, "karizma": 7, "şans": 10},
}

# ===========================================
#   KADER ETİKETLERİ
# ===========================================

def kader_etiketi(gun):
    if gun in [1, 11, 21]: return "eski yolların çağırdığı"
    if gun in [7, 17, 27]: return "orman ruhlarınca işaretlenen"
    if gun in [5, 15, 25]: return "kayıp uygarlığın gölgesinde doğan"
    return "kehanetin rüzgarıyla mühürlenen"


# ===========================================
#   BUFF & ENVANTER SİSTEMİ
# ===========================================

def reset_buffs(character):
    character["buff"] = {"güç": 0, "zeka": 0, "karizma": 0, "şans": 0}

def apply_buff(character, stat, amount):
    character["buff"][stat] += amount

def add_item(character, item_name):
    if item_name not in character["envanter"]:
        character["envanter"].append(item_name)

def has_item(character, item_name):
    return item_name in character["envanter"]

def print_inventory(character):
    print("\n--- ENVANTER ---")
    if not character["envanter"]:
        print("Şu anda yanında özel bir eşya taşımıyorsun.")
    else:
        for i, item in enumerate(character["envanter"], 1):
            print(f"{i}) {item}")
    print("-----------------\n")


# ===========================================
#   STAT OLUŞTURMA + YAŞ BONUSU
# ===========================================

def generate_stats(class_name):
    base = BASE_STATS[class_name]
    final = {}
    for stat, val in base.items():
        r = random.randint(-1, 2)
        final[stat] = max(1, min(10, val + r))
    return final

def apply_age_bonus(character, g, a, y):
    today = date.today()
    age = today.year - y
    if (today.month, today.day) < (a, g):
        age -= 1
    character["yas"] = age

    def add(stat, amount):
        character["statlar"][stat] = min(10, character["statlar"][stat] + amount)

    if age < 18:
        add("şans", 1); add("güç", 1)
    elif 18 <= age <= 25:
        add("güç", 1)
    elif 26 <= age <= 35:
        add("zeka", 1)
    elif 36 <= age <= 45:
        add("karizma", 1); add("zeka", 1)
    else:
        add("şans", 1)


# ===========================================
#   EPİK GİRİŞ METİNLERİ
# ===========================================

EPIC_INTRO = {
    "Savaşçı": """
Gökyüzü doğduğun gece kızıl çizgilerle yarılmıştı.
Elarion’un eski taşlarında yazanlara göre,
böyle bir gece savaşçının kaderini çizer.

Rüzgar, Virdora ormanlarının içinden geçip kapına kadar gelmişti.
Doğa bile seni sınamak için beklemiş gibiydi.

Ortaçağ’da sen…
yıkılmış tapınakların gölgesinde savaşan,
kayıp uygarlığın sırlarını koruyan,
ölümle dans eden bir Savaşçı olurdun.
""",
    # ... diğer sınıf introsu (önceki versiyondaki gibi aynı kalsın) ...
    # Kısaltmak için kesiyorum, sende mevcut EPIC_INTRO içeriği neyse onu koruyabilirsin.
}

# (NOT: Üstteki sözde "..." kısmına önceki mesajda verdiğim tüm EPIC_INTRO gövdelerini aynen bırakabilirsin.
# Onları tekrar yapıştırmak istemiyorsan, sadece en baştaki ve sondaki satırlar arasında eski halini koru.)

# ===========================================
#   KARAKTER OLUŞTURMA
# ===========================================

def create_character():
    print("🕯️ ORTAÇAĞ DÜNYASINA HOŞ GELDİN 🕯️\n")
    isim = input("Kahramanın adı: ")

    while True:
        try:
            t = input("Doğum tarihin (GG.AA.YYYY): ")
            g, a, y = map(int, t.split("."))
            break
        except:
            print("Format hatalı, tekrar dene.")

    burc = get_burc(g, a)
    sinif = BURC_SINIF[burc]
    kader = kader_etiketi(g)

    statlar = generate_stats(sinif)

    karakter = {
        "isim": isim,
        "burç": burc,
        "sınıf": sinif,
        "kader": kader,
        "statlar": statlar,
        "seviye": 1,
        "xp": 0,
        "gorev_index": 0,
        "yas": 0,
        "buff": {},
        "envanter": []
    }

    reset_buffs(karakter)
    apply_age_bonus(karakter, g, a, y)

    # Eğer EPIC_INTRO'da o sınıf yoksa boş bırak
    intro = EPIC_INTRO.get(sinif, "")
    if intro:
        print("\n✨ KARAKTERİN DOĞUŞ HİKAYESİ ✨")
        print(intro)

    print("✨ Statların gizli etkilerle şekillendi:")
    for s, v in statlar.items():
        print(f" - {s.capitalize()}: {v}")

    print(f"\nKader işareti: {kader}\n")

    return karakter


# ===========================================
#   KARAKTER BİLGİSİ GÖSTER
# ===========================================

def print_character(character):
    print("\n--- KARAKTER BİLGİLERİ ---")
    print(f"İsim: {character['isim']}")
    print(f"Burç: {character['burç']}")
    print(f"Sınıf: {character['sınıf']}")
    print(f"Kader: {character['kader']}")
    print(f"Yaş: {character['yas']}")
    print("\nStatlar:")
    for s, v in character["statlar"].items():
        print(f" - {s}: {v}")
    print("\nBufflar:")
    for s, v in character["buff"].items():
        print(f" - {s}: +{v}")
    print("--------------------------\n")
