# engine.py
import random
from character import reset_buffs, has_item

# ==========================================================
#   XP / LEVEL SİSTEMİ
# ==========================================================

def needed_xp(level: int) -> int:
    return level * 50


def level_up(character: dict):
    statlar = character["statlar"]
    adaylar = [s for s, v in statlar.items() if v < 10]
    if adaylar:
        chosen = random.choice(adaylar)
        statlar[chosen] += 1
        print(f"✨ {chosen.capitalize()} +1 arttı!")
    character["seviye"] += 1
    print(f"⬆️ LEVEL UP → Yeni seviye: {character['seviye']}\n")


def gain_xp(character: dict, result: str):
    reward_map = {
        "efsane": 40,
        "başarılı": 25,
        "zor": 15,
        "başarısız": 5
    }
    reward = reward_map[result]
    character["xp"] += reward
    print(f"✨ +{reward} XP kazandın!")

    while character["xp"] >= needed_xp(character["seviye"]):
        character["xp"] -= needed_xp(character["seviye"])
        level_up(character)

    print(f"XP: {character['xp']} / {needed_xp(character['seviye'])}\n")


# ==========================================================
#   ENVANTERDEN GİZLİ BONUS
# ==========================================================

def compute_item_bonus(character: dict, quest_text: str) -> int:
    text = quest_text.lower()
    bonus = 0

    # Kapı / geçit / mühür → anahtar & kapı eşyaları
    if any(k in text for k in ["kapı", "geçit", "mühür"]):
        if has_item(character, "Yosunlu Anahtar"):
            bonus += 2
        if has_item(character, "Kapı Koruyucu Mührü"):
            bonus += 2

    # Mekanizma / dişli / çark → mekanik eşyalar
    if any(k in text for k in ["mekanizma", "dişli", "çark", "ritim"]):
        if has_item(character, "Eski Mekanizma Parçası"):
            bonus += 2
        if has_item(character, "Ana Mekanizma Mührü"):
            bonus += 2

    # Ruh / kehanet / rüzgar → ruhsal eşyalar
    if any(k in text for k in ["ruh", "kehanet", "rüzgar"]):
        if has_item(character, "Ruh Taşı"):
            bonus += 2
        if has_item(character, "Ormanın Mührü"):
            bonus += 1
        if has_item(character, "Zamanın Mührü"):
            bonus += 2

    # Sembol / parşömen / antlaşma → sembolik eşyalar
    if any(k in text for k in ["sembol", "parşömen", "antlaşma", "mektup", "yazı"]):
        if has_item(character, "Sembol Parşömeni"):
            bonus += 2
        if has_item(character, "Unutulmuş Dilin Mührü"):
            bonus += 2
        if has_item(character, "Diplomasi Mührü"):
            bonus += 1

    # Orman / denge / doğa → şifacı & orman eşyaları
    if any(k in text for k in ["orman", "ağaç", "kök", "denge"]):
        if has_item(character, "Orman Özü"):
            bonus += 2
        if has_item(character, "Denge Taşı"):
            bonus += 1

    if bonus > 0:
        print("✨ Yanında taşıdığın bazı eşyaların fark edilmeden sana yardım ettiğini hissediyorsun.")
    return bonus


# ==========================================================
#   GÖREV BAĞLAMINA GÖRE SEÇENEKLER
# ==========================================================

OPTION_SETS = {
    # TAPINAK / ALT KAT / MÜHÜR
    "tapinak": [
        (
            "Tapınağın duvarlarındaki oyma ve çatlakları dikkatle incelersin.",
            +1,
            [
                ("Sembollerin dizilişinde saklı bir düzen ararsın.", +2),
                ("Çatlakların birleştiği noktada gizli bir bölme ararsın.", +1),
                ("Taşların dokusundaki farklılığı parmaklarınla yoklarsın.", 0),
            ],
        ),
        (
            "Zemin taşlarının arasında basınca duyarlı bir mekanizma olup olmadığına bakarsın.",
            +2,
            [
                ("Hafif oynayan taşları tek tek denersin.", +2),
                ("Ayak seslerinin yankısındaki değişimi dinlersin.", +1),
                ("Sadece en eski görünen taşlara odaklanırsın.", 0),
            ],
        ),
        (
            "Tapınağın ortasındaki alanın ritüel için kullanılıp kullanılmadığını anlamaya çalışırsın.",
            0,
            [
                ("Yer çizimlerini geçmiş ritüellerle kıyaslarsın.", +2),
                ("Tavan oymalarındaki figürleri yorumlarsın.", +1),
                ("Hiç dokunmadan sadece enerjiyi sezgilerinle okumaya çalışırsın.", 0),
            ],
        ),
    ],

    # ORMAN / İZ / RÜZGAR
    "orman": [
        (
            "Toprağa ve ağaç gövdelerine sinmiş izleri incelemeye başlarsın.",
            +1,
            [
                ("Ayak izlerinin derinliğinden ağırlık ve yön hesaplamaya çalışırsın.", +2),
                ("Kırık dalların çizdiği hattı takip edersin.", +1),
                ("Sadece taze görünen izlere odaklanırsın.", 0),
            ],
        ),
        (
            "Kısa bir süre durup ormanın sesini dinlersin.",
            0,
            [
                ("Kuşların sustuğu yönü tehlike kabul edersin.", +1),
                ("Uzak bir dal kırılma sesini takip edersin.", +1),
                ("Rüzgarın yön değiştirdiği anı işaret kabul edersin.", 0),
            ],
        ),
        (
            "Ağaçların dizilişinde ve yosunların tarafında bir desen ararsın.",
            +2,
            [
                ("Benzer işaretli ağaçların bulunduğu hattı izlersin.", +2),
                ("Yosunun yoğun olduğu tarafı güvenli kabul edersin.", +1),
                ("Açıklığa açılan yolu bulmaya çalışırsın.", 0),
            ],
        ),
    ],

    # GEÇİT / KAPI
    "gecit": [
        (
            "Kapının etrafındaki taşlarda gizli bir kilit veya oyuk ararsın.",
            +2,
            [
                ("Küçük bir anahtar deliği olup olmadığını incelersin.", +2),
                ("Eşit aralıklarla yerleştirilmiş taşlara dikkat edersin.", +1),
                ("Taşların arasındaki hava akımını parmaklarınla yoklarsın.", 0),
            ],
        ),
        (
            "Kapının önünde durup içerden gelen en ufak sesi dinlersin.",
            +1,
            [
                ("Metal sürtünmesine benzeyen sesleri ayırt etmeye çalışırsın.", +2),
                ("Tahta veya taş sürtünmesi varsa kaynağını kestirmeye çalışırsın.", +1),
                ("Hiç ses duymasanda kalbinin ritmine güvenirsin.", 0),
            ],
        ),
        (
            "Kapıya doğrudan değil, yanlardan yaklaşarak alternatif bir yol ararsın.",
            0,
            [
                ("Yan duvarların arkasında gizli bir geçit olabileceğini düşünürsün.", +1),
                ("Üstten sarkan kök ve kirişleri inceleyerek zayıf bir nokta ararsın.", +1),
                ("Çatlaklardan sızan hava veya ışığı takip edersin.", 0),
            ],
        ),
    ],

    # MEKANİZMA / DİŞLİ / ÇARK
    "mekanizma": [
        (
            "Düzenekteki dişli ve çarkları tek tek gözden geçirirsin.",
            +2,
            [
                ("Hangi dişlinin kilit görevi gördüğünü bulmaya çalışırsın.", +2),
                ("En paslı görünen parçanın işlevini sorgularsın.", +1),
                ("Hiç oynamayan parçaları not alırsın.", 0),
            ],
        ),
        (
            "Mekanizmanın çevresinde tetikleyici taşlar veya kollar ararsın.",
            +1,
            [
                ("Basınca duyarlı bir taş plakayı test edersin.", +1),
                ("Hafif itince oynayan parçaları tespit etmeye çalışırsın.", +1),
                ("Sistemi önce bir süre sadece gözlemlemeyi seçersin.", 0),
            ],
        ),
        (
            "Geçmişte gördüğün benzer düzenekleri hatırlamaya çalışırsın.",
            0,
            [
                ("Zihninde daha önce çözdüğün mekanizmalarla kıyaslarsın.", +2),
                ("Mantığa en yakın çözümü önceliklendirirsin.", +1),
                ("Küçük, güvenli denemelerle sistemi yoklarsın.", 0),
            ],
        ),
    ],

    # RUH / KEHANET / RÜZGAR
    "ruh": [
        (
            "Ruhların varlığını kabul edip saygıyla ilerlersin.",
            +2,
            [
                ("İçinden kısa bir selam verip yol istersin.", +1),
                ("Küçük bir adak bırakmayı tercih edersin.", +1),
                ("Niyetini açık ve sakin tutmaya odaklanırsın.", 0),
            ],
        ),
        (
            "Ruhların göndermek istediği işaretleri okumaya çalışırsın.",
            +1,
            [
                ("Rüzgarın anlık yön değişimini işaret kabul edersin.", +1),
                ("Ağaçların hışırtısındaki ritmi yorumlamaya çalışırsın.", +2),
                ("En baskın hissi takip edersin.", 0),
            ],
        ),
        (
            "Ruhlara belli bir mesafe koyarak temkinli ilerlersin.",
            0,
            [
                ("Onları rahatsız etmemek için yavaş hareket edersin.", +1),
                ("Geri çekilme ihtimalini zihninde hep açık tutarsın.", +1),
                ("Sadece gözlemci kalıp not almakla yetinirsin.", 0),
            ],
        ),
    ],

    # SEMBOL / PARŞÖMEN / ANTLAŞMA
    "sembol": [
        (
            "Sembollerin dizilişini ve tekrar eden işaretleri incelersin.",
            +2,
            [
                ("Tekrarlayan şekillerden bir anlam çıkarmaya çalışırsın.", +2),
                ("Yön gösteren sembolleri diğerlerinden ayırırsın.", +1),
                ("Okuyamadıklarını şimdilik görmezden gelirsin.", 0),
            ],
        ),
        (
            "Sembolleri bildiğin eski dillerle kıyaslamaya çalışırsın.",
            +1,
            [
                ("Benzerini gördüğün harf ve işaretleri eşleştirirsin.", +2),
                ("En tanıdık gelen kök kelimelere odaklanırsın.", +1),
                ("Sadece en net okunabilen kısmı temel alırsın.", 0),
            ],
        ),
        (
            "Sembollerin bulunduğu yüzeyi fiziksel olarak yoklarsın.",
            0,
            [
                ("Bazı işaretleri hafifçe iterek gizli bir düğme ararsın.", +1),
                ("Çizgilerin birleştiği noktaya dikkat kesilirsin.", +1),
                ("Hiç dokunmadan sadece çevresini incelersin.", 0),
            ],
        ),
    ],

    # SAVAŞ / SİPER / GARNİZON
    "savas": [
        (
            "Saha düzenine bir komutan gibi yukarıdan bakmaya çalışırsın.",
            +2,
            [
                ("Olası saldırı ve savunma hatlarını kafanda çizersin.", +2),
                ("En zayıf görünen noktayı özellikle incelersin.", +1),
                ("Önce geri çekilme yollarını güvence altına alırsın.", 0),
            ],
        ),
        (
            "Topraktaki izleri ve siper duvarlarını inceleyerek yakın geçmişi okumaya çalışırsın.",
            +1,
            [
                ("Ayak izlerinin yönünden hareketi tahmin edersin.", +1),
                ("Silah ve zırh parçalarından çatışmanın şiddetini analiz edersin.", +2),
                ("Boş kovan, kırık ok vb. küçük detaylara odaklanırsın.", 0),
            ],
        ),
        (
            "Askerlerin moralini ve düzenini hayal ederek senaryo kurarsın.",
            0,
            [
                ("Baskı altında nasıl davranacaklarını zihninde canlandırırsın.", +1),
                ("Hangi emrin kaosa yol açacağını tahmin etmeye çalışırsın.", +1),
                ("En kötü senaryoyu düşünüp ona göre plan yaparsın.", 0),
            ],
        ),
    ],

    # GÖLGE / CASUSLUK / TÜNEL
    "golge": [
        (
            "Işık kaynaklarını ve gölgelerin düştüğü açıları analiz edersin.",
            +2,
            [
                ("Gölgenin gerçek sahibi olabilecek noktaları hesap edersin.", +2),
                ("Gizlenmek için en uygun karanlık noktayı belirlersin.", +1),
                ("Kendini duvarla birleştirip izlenip izlenmediğini test edersin.", 0),
            ],
        ),
        (
            "Ayak sesleri, nefes alışlar ve kuma basışları gibi sessiz izleri dinlersin.",
            +1,
            [
                ("Sadece düzenli ritim taşıyan adımlara odaklanırsın.", +1),
                ("Duran birinin nefesini yakalamaya çalışırsın.", +2),
                ("Kısa süreli sessizlik anlarını fırsat olarak görürsün.", 0),
            ],
        ),
        (
            "Geri çekilme ve takip rotalarını aynı anda planlarsın.",
            0,
            [
                ("Birden fazla kaçış noktasını zihninde işaretlersin.", +1),
                ("Takip edilmen ihtimaline karşı ters manevralar düşünürsün.", +1),
                ("Yolu bilerek uzatıp izini kaybettirmeyi hesaplarsın.", 0),
            ],
        ),
    ],

    # KORUMA / KAPI / NÖBET
    "koruma": [
        (
            "Kapının zayıf ve güçlü noktalarını bir muhafız gözüyle incelersin.",
            +2,
            [
                ("Menteşe ve kilit kısımlarını tek tek yoklarsın.", +2),
                ("Duvarın taşıyamayacağı yük noktalarını belirlersin.", +1),
                ("Çevrede saldırıya açık kör noktaları işaretlersin.", 0),
            ],
        ),
        (
            "Nöbet rotasını ve giriş-çıkış trafiğini kafanda çizersin.",
            +1,
            [
                ("Nöbet döngüsünde açıkta kalan anları bulursun.", +2),
                ("Beklenmedik bir saldırıya karşı en savunmasız anı tespit edersin.", +1),
                ("Gerektiğinde kapıyı kilitlemek için en uygun zamanı hesaplarsın.", 0),
            ],
        ),
        (
            "Kapının ardındaki tehdidi tahmin etmeye çalışırsın.",
            0,
            [
                ("Ses, koku ve titreşimlerden içerideki varlığı anlamaya çalışırsın.", +1),
                ("Kötü ihtimalleri sırayla hesaplayıp olası çözümler düşünürsün.", +1),
                ("Kendi korkunu bastırıp sakin kalmaya odaklanırsın.", 0),
            ],
        ),
    ],

    # DİPLOMASİ / ANTLAŞMA / LİDER
    "diplomasi": [
        (
            "Metindeki kelimeleri ve cümle yapılarını dikkatle incelersin.",
            +2,
            [
                ("Taraflara avantaj sağlayan ifadeleri ayıklarsın.", +2),
                ("Belirsiz bırakılmış bölümleri işaretlersin.", +1),
                ("Çeviri hatası olabilecek yerleri not alırsın.", 0),
            ],
        ),
        (
            "Tarafların bakış açısından olayı ayrı ayrı düşünürsün.",
            +1,
            [
                ("Her tarafın kazanım ve kayıplarını hesaplamaya çalışırsın.", +2),
                ("Yanlış anlaşılmaya açık noktaları bulursun.", +1),
                ("İki tarafın ortak çıkarını maksimize eden yolu ararsın.", 0),
            ],
        ),
        (
            "Sözlü ve sözsüz mesajları birlikte okursun.",
            0,
            [
                ("Ses tonlarındaki değişimi yorumlamaya çalışırsın.", +1),
                ("Bakışların kaçtığı anları özel not edersin.", +1),
                ("Sahte nezaket ile gerçek niyeti ayırmaya odaklanırsın.", 0),
            ],
        ),
    ],

    # GENEL / HER DURUM
    "genel": [
        (
            "Bulunduğun ortamı bütünüyle tarar, hızlıca genel bir tablo çıkarırsın.",
            +1,
            [
                ("Önce en bariz ipuçlarını toplarsın.", +1),
                ("Zayıf noktaları kabaca işaretlersin.", +2),
                ("Hiç acele etmeden güvenli bir alan belirlersin.", 0),
            ],
        ),
        (
            "Kısa bir süre durup durumu zihninde yeniden kurgularsın.",
            +2,
            [
                ("Olayları başa sarıp mantık sırasına koyarsın.", +2),
                ("İçgüdülerinin gösterdiği yöne öncelik verirsin.", +1),
                ("Hiç risk almadan küçük adımlarla test etmeyi seçersin.", 0),
            ],
        ),
        (
            "Küçük ama kritik detaylara odaklanırsın.",
            0,
            [
                ("Çok az kişinin fark edeceği izleri ararsın.", +1),
                ("Ses, koku ve dokuyu birlikte yorumlamaya çalışırsın.", +1),
                ("Birkaç küçük deneme yaparak tepkileri ölçersin.", 0),
            ],
        ),
    ],
}


def detect_context(quest_text: str) -> str:
    t = quest_text.lower()

    if "tapınak" in t or "tapınağın" in t:
        return "tapinak"
    if any(k in t for k in ["orman", "ağaç", "kök"]):
        return "orman"
    if any(k in t for k in ["geçit", "kapı", "kapının", "kapıya"]):
        return "gecit"
    if any(k in t for k in ["mekanizma", "dişli", "çark", "ritim"]):
        return "mekanizma"
    if any(k in t for k in ["ruh", "kehanet", "rüzgar"]):
        return "ruh"
    if any(k in t for k in ["sembol", "parşömen", "mühür", "antlaşma"]):
        return "sembol"
    if any(k in t for k in ["savaş", "siper", "garnizon", "ordu"]):
        return "savas"
    if any(k in t for k in ["gölge", "casus", "tünel", "suikast"]):
        return "golge"
    if any(k in t for k in ["nöbet", "nöbetçi", "koru", "savun"]):
        return "koruma"
    if any(k in t for k in ["elçi", "taraf", "lider", "diplom", "müzakere"]):
        return "diplomasi"

    return "genel"


def choose_stat_for_context(context: str) -> str:
    if context in ["tapinak", "mekanizma", "sembol", "diplomasi"]:
        candidates = ["zeka"]
    elif context in ["gecit", "golge", "savas"]:
        candidates = ["şans", "zeka"]
    elif context in ["ruh", "orman"]:
        candidates = ["karizma", "şans"]
    elif context == "koruma":
        candidates = ["güç", "zeka"]
    else:
        candidates = ["güç", "zeka", "karizma", "şans"]
    return random.choice(candidates)


# ==========================================================
#   GÖREV MOTORU
# ==========================================================

def play_quest(character: dict, quest_text: str) -> str:
    """
    Bir görevi oynatır:
    - Görev metnini gösterir
    - Bağlama göre 3 seçenek çıkarır
    - Seçilen seçeneğin altına 3 alt seçenek çıkarır
    - Stat + buff + seçim + item + rastgelelik ile sonucu hesaplar
    - XP verir, buff'ları sıfırlar
    """

    # Görev metni
    print("\n--- Görev ---\n")
    print(quest_text)
    input("\n➡ Devam etmek için Enter’a bas...\n")

    # Bağlama göre seçenek seti
    context = detect_context(quest_text)
    options = OPTION_SETS[context]

    print("\n--- Nasıl ilerleyeceksin? ---\n")
    for i, (text, _bonus, _subs) in enumerate(options, 1):
        print(f"{i}) {text}")

    # Ana seçenek
    while True:
        try:
            choice = int(input("\nSeçimin (1-3): "))
            if choice in (1, 2, 3):
                break
        except:
            pass
        print("Geçersiz seçim, tekrar dene.")

    main_text, main_bonus, suboptions = options[choice - 1]
    print(f"\n→ {main_text}\n")

    # Alt seçenekler
    print("Sonrasında ne yaparsın?\n")
    for i, (text, _b) in enumerate(suboptions, 1):
        print(f"{i}) {text}")

    while True:
        try:
            sub_choice = int(input("\nSeçimin (1-3): "))
            if sub_choice in (1, 2, 3):
                break
        except:
            pass
        print("Geçersiz seçim, tekrar dene.")

    sub_text, sub_bonus = suboptions[sub_choice - 1]
    print(f"\n→ {sub_text}\n")

    # Stat & bonus hesabı
    chosen_stat = choose_stat_for_context(context)
    temel = character["statlar"][chosen_stat]
    buff = character["buff"][chosen_stat]
    rast = random.randint(-2, 3)
    item_bonus = compute_item_bonus(character, quest_text)

    toplam = temel + buff + main_bonus + sub_bonus + item_bonus + rast

    print("------ SONUÇ ------")
    print(f"Kullanılan temel özellik: {chosen_stat} ({temel})")
    if buff:
        print(f"Geçici avantajın: +{buff}")
    print(f"Seçimlerinden gelen etki: +{main_bonus} / +{sub_bonus}")
    if item_bonus > 0:
        print(f"Eşyaların gizli katkısı: +{item_bonus}")
    print(f"Kaderin dokunuşu: {rast:+}")
    print(f"TOPLAM: {toplam}\n")

    if toplam >= 15:
        print("🌟 EFSANE BİR BAŞARI! Yolun senin için açılıyor.")
        result = "efsane"
    elif toplam >= 10:
        print("✅ Başarılı! Zorlukları aşarak ilerliyorsun.")
        result = "başarılı"
    elif toplam >= 6:
        print("⚠️ Zorlandın ama pes etmiyorsun, yoluna devam ediyorsun.")
        result = "zor"
    else:
        print("❌ Bu sefer başaramadın… ama bu dünya ikinci şans tanır.")
        result = "başarısız"

    print()
    gain_xp(character, result)
    reset_buffs(character)

    return result
