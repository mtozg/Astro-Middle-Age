# quests.py
# 12 sınıf × 6 görev = 72 görevlik tam görev motoru

import random

QUEST_DATA = {

    # --------------------------------------------------------
    # SAVAŞÇI
    # --------------------------------------------------------
    "Savaşçı": [
        {
            "prelude": "Eski savaş meydanlarında yürürken rüzgarın adını fısıldadığını hissedersin. "
                       "Toprak titrer — bir şey uyanıyor olabilir.",
            "task": "Eski savaş alanındaki titremenin kaynağını araştır.",
            "reward": "Yosunlu Anahtar"
        },
        {
            "prelude": "Gece, tapınağın batı duvarında çatlak bir mühür belirdi. Çatlaktan sızan ışık doğal değil...",
            "task": "Tapınaktaki çatlak mühür ışığını incele.",
            "reward": "Ruh Taşı"
        },
        {
            "prelude": "Ormanın içinde guttural bir kükreme yankılanıyor. Ağaçlar iki yana eğilmiş; bir şey buradan geçmiş.",
            "task": "Kükremenin kaynağını bulmak için iz sür.",
            "reward": None
        },
        {
            "prelude": "Orman ruhları sana bir işaret gönderiyor. Bozulmuş bir ritüel alanından bahsediyorlar.",
            "task": "Bozulmuş ritüel alanını araştır.",
            "reward": "Savaşçı Rünü"
        },
        {
            "prelude": "Tapınaktaki eski mekanizma kendi kendine çalışmaya başladı. Dişliler yerinden oynuyor...",
            "task": "Tapınaktaki mekanizmanın neden tetiklendiğini çöz.",
            "reward": "Eski Mekanizma Parçası"
        },
        {
            "prelude": "Gökyüzü kızıl bir ateşe büründü. Kırılan mühür savaş ruhunu çağırıyor...",
            "task": "Uyanan savaş ruhuyla yüzleş ve mühürü kapat.",
            "reward": "Savaşın Koruyucu Mührü"
        }
    ],

    # --------------------------------------------------------
    # KAŞİF
    # --------------------------------------------------------
    "Kaşif": [
        {
            "prelude": "Eski bir keşif günlüğünde yırtılmış bir harita parçası buldun. Üzerindeki sembol Elarion’un Gözü...",
            "task": "Haritanın ait olduğu geçidi bul.",
            "reward": "Kırık Harita Parçası"
        },
        {
            "prelude": "Haritadaki işaret seni Virdora köklerinin altındaki gizli kapağa götürdü.",
            "task": "Köklerin altındaki gizli geçidi aç ve nereye çıktığını keşfet.",
            "reward": "Yosunlu Anahtar"
        },
        {
            "prelude": "Geçidin sonu eski bir tapınağın alt katına çıkıyor; duvarlar titriyor.",
            "task": "Tapınak altındaki mekanik titreşimin kaynağını bul.",
            "reward": "Eski Mekanizma Parçası"
        },
        {
            "prelude": "Tapınak duvarlarında bilinmeyen bir sembol dizilimi var. Bazıları hareket ediyor.",
            "task": "Sembollerin dizilimini çöz ve gizli geçidi bul.",
            "reward": "Sembol Parşömeni"
        },
        {
            "prelude": "Sembollerin gösterdiği yol seni dev bir taş çarkın önüne getirdi.",
            "task": "Mekanizmayı tekrar çalıştırmak için eksik parçayı bul.",
            "reward": "İşaretli Dişli"
        },
        {
            "prelude": "Haritanın tüm parçaları birleşti; Elarion’un Kayıp Yolu açılmak üzere.",
            "task": "Kayıp yolu açmak için tüm parçaları birleştir.",
            "reward": "Elarion Yolcusu Mührü"
        }
    ],

    # --------------------------------------------------------
    # BİLGİN
    # --------------------------------------------------------
    "Bilgin": [
        {
            "prelude": "Kütüphanedeki eski bir parşömen kendiliğinden açıldı ve semboller parladı.",
            "task": "Parşömenin ilk sembol dizisini çöz.",
            "reward": "Sembol Parşömeni – 1. Katman"
        },
        {
            "prelude": "Tapınak duvarındaki semboller parşömenle aynı, ancak bozulmuş.",
            "task": "Bozuk sembolleri düzelt ve gizli bölmeyi aç.",
            "reward": "Taş Anahtar Parçası (1/2)"
        },
        {
            "prelude": "Sembolleri düzelttiğinde tapınağın altından fısıltılar duydun.",
            "task": "Fısıltıların kaynağını bul.",
            "reward": "Taş Anahtar Parçası (2/2)"
        },
        {
            "prelude": "Taş anahtar birleşti ve dil kapısı ortaya çıktı.",
            "task": "Dil kapısının mekanizmasını çöz.",
            "reward": "Elarion Taş Anahtarı"
        },
        {
            "prelude": "Kapı açıldı ve dev bir sembol arşivi ortaya çıktı.",
            "task": "Sembol haritasını çöz ve merkeze ulaş.",
            "reward": "Sonsuz Bilgi Fragmanı"
        },
        {
            "prelude": "Taş küre sembolleri etrafında döndürerek sana bir bilmece soruyor.",
            "task": "Kehanetin son bilmecesini çöz.",
            "reward": "Unutulmuş Dilin Mührü"
        }
    ],

    # --------------------------------------------------------
    # KEHANETÇİ
    # --------------------------------------------------------
    "Kehanetçi": [
        {
            "prelude": "Rüzgar sana kendi sesinde fısıldadı. Bu bir kehanet başlangıcı olabilir.",
            "task": "Fısıltının kaynağını çöz.",
            "reward": "Rüzgarın İşareti"
        },
        {
            "prelude": "Ruhların toplandığı bölgede toprak nefes alıyordu.",
            "task": "Kehanet halkasının amacını çöz.",
            "reward": "Ruh Taşı"
        },
        {
            "prelude": "Tapınakta ışık huzmesi göğe yükseldi.",
            "task": "Işık huzmesinin kehanetle bağlantısını bul.",
            "reward": "Kehanet Parşömeni (1/2)"
        },
        {
            "prelude": "Gece zaman ipliği bir anlığına durdu.",
            "task": "Zaman ipliğini takip ederek kehanetin sonraki bölümünü bul.",
            "reward": "Kehanet Parşömeni (2/2)"
        },
        {
            "prelude": "Bir varlık seni izliyor; kehanet gölgesini buldun.",
            "task": "Gölgedeki varlığı ortaya çıkar.",
            "reward": "Gölgeli Rün"
        },
        {
            "prelude": "Fısıltının sahibi gelecekteki sensin.",
            "task": "Zaman döngüsünü kır.",
            "reward": "Zamanın Mührü"
        }
    ],

    # --------------------------------------------------------
    # CASUS
    # --------------------------------------------------------
    "Casus": [
        {
            "prelude": "Duvara düşen gölge seni takip ediyor gibiydi.",
            "task": "Gölgenin bıraktığı izleri çöz.",
            "reward": "Gölgeli Sembol"
        },
        {
            "prelude": "Ormanda sahte izler ve gerçek rotalar karışmış.",
            "task": "Gerçek rotayı ayıkla.",
            "reward": "Sessiz Adımlar Kaydı"
        },
        {
            "prelude": "Yosunlu kapının ardında gizli bir toplantı var.",
            "task": "Toplantıyı kapıyı açmadan çöz.",
            "reward": "Yosunlu Anahtar"
        },
        {
            "prelude": "Toprak altında gizli bir tünel buldun.",
            "task": "Tünelin nereye çıktığını keşfet.",
            "reward": "Tünel Haritası Parçası"
        },
        {
            "prelude": "Tapınakta sahte ritüel kurulmuş.",
            "task": "Sahte ritüelin neyi gizlediğini bul.",
            "reward": "Sahte Mühür Taşı"
        },
        {
            "prelude": "Gölgelerdeki Ağ’ın merkezi seni bekliyor.",
            "task": "Ağın liderini ortaya çıkar.",
            "reward": "Gölgelerdeki Ağ Mührü"
        }
    ],

    # --------------------------------------------------------
    # SUİKASTÇI
    # --------------------------------------------------------
    "Suikastçı": [
        {
            "prelude": "Duvarda hareket eden ama kaynağı görünmeyen bir gölge gördün.",
            "task": "Gölgenin kaynağını araştır.",
            "reward": "Sessiz Adım İşareti"
        },
        {
            "prelude": "Ormanda kanla yazılmış gizli bir mesaj buldun.",
            "task": "Mesajı çöz ve nereye götürdüğünü bul.",
            "reward": "Karanlık Yol Haritası"
        },
        {
            "prelude": "Kilitli bir kuleye biri iz bırakmadan girmiş.",
            "task": "Kuleye sessizce sız.",
            "reward": "Tırmanma Kancası"
        },
        {
            "prelude": "Tapınak yolunda görünmez tuzaklar var.",
            "task": "Tuzakları fark et ve etkisiz hale getir.",
            "reward": "Tuzak Ustası Notları"
        },
        {
            "prelude": "Yarım maske sembolü yanlış hedefe işaret ediyor olabilir.",
            "task": "Hedefin kim olduğunu belirle.",
            "reward": "Yarım Maske"
        },
        {
            "prelude": "Gördüğün izlerin hepsi seni gösteriyor — gerçek Sessiz Adım sensin.",
            "task": "Gölgelerin ardındaki gerçeği bul.",
            "reward": "Sessiz Adımın Mührü"
        }
    ],

    # --------------------------------------------------------
    # ŞİFACI
    # --------------------------------------------------------
    "Şifacı": [
        {
            "prelude": "Ormanın girişindeki ağaç acı çekiyor.",
            "task": "Ağacın acısının kaynağını bul.",
            "reward": "Orman Özü"
        },
        {
            "prelude": "Denge halkası kırılmış; enerji kaos içinde.",
            "task": "Denge halkasının neden kırıldığını çöz.",
            "reward": "Denge Taşı"
        },
        {
            "prelude": "Ormanın bir bölümü sisle kaplanmış.",
            "task": "Sisin gizlediği yarayı bul.",
            "reward": "Ruh İpliği"
        },
        {
            "prelude": "Ruh ipliği seni bir yere çağırıyor.",
            "task": "Ruhun verdiği işareti çöz.",
            "reward": "Ruhun Sembolü"
        },
        {
            "prelude": "Toprak zehirlenmiş; kökler kuruyor.",
            "task": "Zehirli bölgenin kaynağını bul.",
            "reward": "Arındırma Küresi"
        },
        {
            "prelude": "Ormanın ruhu iyileştirilmek üzere seni bekliyor.",
            "task": "Şifa ritüelini tamamla.",
            "reward": "Ormanın Mührü"
        }
    ],

    # --------------------------------------------------------
    # KOMUTAN
    # --------------------------------------------------------
    "Komutan": [
        {
            "prelude": "Siperlerde yeni izler var — biri hazırlık yapmış.",
            "task": "Bu izlerin kim tarafından bırakıldığını öğren.",
            "reward": "Savaş Toprağı Parçası"
        },
        {
            "prelude": "İki çelişkili emir bulunmuş.",
            "task": "Emirlerin kaynağını bul.",
            "reward": "Komuta Mührü (1/2)"
        },
        {
            "prelude": "Garnizon kaybolmuş; iz yok.",
            "task": "Kaybolan askerlerin izini bul.",
            "reward": "Komuta Mührü (2/2)"
        },
        {
            "prelude": "Semboller Kül Krallığı yeminine işaret ediyor.",
            "task": "Yemin izlerini çöz.",
            "reward": "Kül Mührü Parçası"
        },
        {
            "prelude": "Sahte komutan ortaya çıkmış.",
            "task": "Sahte komutanı belirle.",
            "reward": "Gerçek Komutan Kaydı"
        },
        {
            "prelude": "Kül mühürü tamamlanmak üzere.",
            "task": "Mührün tamamlanmasını durdur.",
            "reward": "Kül Krallığı Mührü"
        }
    ],

    # --------------------------------------------------------
    # MUCİT
    # --------------------------------------------------------
    "Mucit": [
        {
            "prelude": "Terk edilmiş işlikte bir çark kendiliğinden dönüyor.",
            "task": "Çarkı çalıştıran gücü bul.",
            "reward": "Dişli Parçası (1/2)"
        },
        {
            "prelude": "Gece duvarlardan ritmik tıkırtılar geliyor.",
            "task": "Tıkırtının kaynağını bul.",
            "reward": "Çelik Yağ Şişesi"
        },
        {
            "prelude": "Toprak manyetik bir taşın üzerinde titreşiyor.",
            "task": "Manyetik taşın neyi tetiklediğini çöz.",
            "reward": "Manyetik Çekirdek"
        },
        {
            "prelude": "Bir mekanizmanın ritim kolu ortaya çıktı.",
            "task": "Ritim kolunu tamamlamak için parçayı bul.",
            "reward": "Dişli Parçası (2/2)"
        },
        {
            "prelude": "Duvarda kırmızı ışıklar yanıyor: aşırı yük.",
            "task": "Aşırı yükün kaynağını bul ve mekanizmayı koru.",
            "reward": "Enerji Sigorta Parçası"
        },
        {
            "prelude": "Ana mekanizma tüm parçaları bekliyor.",
            "task": "Elarion’un Ana Mekanizmasını çalıştır.",
            "reward": "Ana Mekanizma Mührü"
        }
    ],

    # --------------------------------------------------------
    # DİPLOMAT
    # --------------------------------------------------------
    "Diplomat": [
        {
            "prelude": "Yırtılmış bir antlaşma metni buldun.",
            "task": "Antlaşmanın taraflarını belirle.",
            "reward": "Antlaşma Mührü (1/2)"
        },
        {
            "prelude": "Elçi ormanda kaybolmuş.",
            "task": "Elçinin akıbetini öğren.",
            "reward": "Elçi Notu"
        },
        {
            "prelude": "Gizli toplantı iptal edilmiş; semboller değiştirilmiş.",
            "task": "Toplantının neden bozulduğunu bul.",
            "reward": "Barış Sembolü Taşı"
        },
        {
            "prelude": "Diplomatik mesaj labirenti bozulmuş.",
            "task": "Mesaj dizilimini düzelt.",
            "reward": "Antlaşma Mührü (2/2)"
        },
        {
            "prelude": "Antlaşma metninin bir versiyonu manipüle edilmiş.",
            "task": "Metni kim değiştirdi?",
            "reward": "Gölge Diplomasi Kaydı"
        },
        {
            "prelude": "Savaş kapıda — diplomasi tek şans.",
            "task": "Antlaşmayı yeniden kur ve barışı sağla.",
            "reward": "Diplomasi Mührü"
        }
    ],

    # --------------------------------------------------------
    # ŞÖVALYE
    # --------------------------------------------------------
    "Şövalye": [
        {
            "prelude": "Eski kralın kalkanı kırılmış.",
            "task": "Kalkanın nasıl kırıldığını öğren.",
            "reward": "Onur Parçası (1/2)"
        },
        {
            "prelude": "Nöbetçi donmuş halde bulunuyor.",
            "task": "Nöbetçinin durumunu çöz.",
            "reward": "Onur Parçası (2/2)"
        },
        {
            "prelude": "Eski kralın asası çalınmış.",
            "task": "Asayı çalan kişiyi bul.",
            "reward": "Yemin Kaydı"
        },
        {
            "prelude": "Yemin bozulmuş; şövalyeler dengesiz.",
            "task": "Yemin bozulmasının etkisini çöz.",
            "reward": "Kral Mührü Parçası"
        },
        {
            "prelude": "Kral mührünün diğer parçası savaş meydanında.",
            "task": "Mührü ele geçir.",
            "reward": "Kral Mührü"
        },
        {
            "prelude": "Yemin yeniden canlandırılmak üzere.",
            "task": "Kral yeminini tamamla.",
            "reward": "Onur Mührü"
        }
    ],

    # --------------------------------------------------------
    # MUHAFIZ
    # --------------------------------------------------------
    "Muhafız": [
        {
            "prelude": "Tapınak kapısı gece kendi kendine titredi.",
            "task": "Kapının neden titrediğini bul.",
            "reward": "Kapı Mührü (1/2)"
        },
        {
            "prelude": "Nöbetçinin zırhı var ama kendisi yok.",
            "task": "Nöbetçinin nasıl kaybolduğunu çöz.",
            "reward": "Nöbetçi Kaydı"
        },
        {
            "prelude": "Kapının iç tarafında görünmez bir mekanizma var.",
            "task": "Gizli kilidi çöz.",
            "reward": "Kapı Mührü (2/2)"
        },
        {
            "prelude": "Kapının ardında ikinci bir geçit var.",
            "task": "İkinci kapının işaretini bul.",
            "reward": "Geçit Sembolü"
        },
        {
            "prelude": "Bir grup kapıya saldırı planlıyor.",
            "task": "Saldırı planını yapanları bul.",
            "reward": "Savunma Rünü"
        },
        {
            "prelude": "Kapının gerçek nöbetçisi olarak çağrılıyorsun.",
            "task": "Geçitteki tehdidi durdur.",
            "reward": "Kapı Koruyucu Mührü"
        }
    ],

}

quest_progress = {}

def get_next_quest(character):
    cls = character.get("sınıf")

    if cls not in QUEST_DATA:
        print("Bu sınıfa ait görev bulunamadı.")
        return None

    # daha önce hiç görev alınmadıysa 0'dan başla
    index = character.get("görev_index", 0)

    # tüm görevler bitmiş mi?
    if index >= len(QUEST_DATA[cls]):
        return None

    quest = QUEST_DATA[cls][index]

    # bir sonrakine geçebilmek için index'i arttır
    character["görev_index"] = index + 1

    return quest

def play_prelude(character, quest):
    prelude = quest.get("prelude", "")
    if prelude:
        print("\n--- GÖREV ÖNCESI ---")
        print(prelude)
        print("--------------------\n")

def get_quest_reward(character):
    sinif = character["sınıf"]
    rewards = [
        "Gizemli Taş",
        "Eski Parşömen",
        "Büyülü Toz",
        "Ruh Özü",
        "Gölge Parçası"
    ]
    return random.choice(rewards)
