from character import (
    create_character,
    print_character,
    apply_buff,
    reset_buffs,
    add_item,
    print_inventory,
)
from quests import get_next_quest, play_prelude
from engine import play_quest
from choice_tree import has_choice_tree, play_choice_tree
import random

def free_time_menu(character):
    print("\n--- Serbest Zaman ---")
    print("1) Kitap oku")
    print("2) Antrenman yap")
    print("3) Ormanda kısa bir yürüyüş yap")
    print("4) Menüye dön")
    sec = input("\nSeçimin: ")

    if sec == "1":
        print("\n📚 Hangi kitabı okumak istersin?")
        print("1) Keşif Günlükleri (+1 zeka)")
        print("2) Orman Ruhlarının Hikâyeleri (+1 karizma)")
        print("3) Elarion Sembolleri (+2 zeka)")
        print("4) Eski Yolculuklar (+1 şans)")
        kitap = input("\nSeçimin: ")
        if kitap == "1": apply_buff(character, "zeka", 1)
        elif kitap == "2": apply_buff(character, "karizma", 1)
        elif kitap == "3": apply_buff(character, "zeka", 2)
        elif kitap == "4": apply_buff(character, "şans", 1)
        print("📘 Kitabı tamamladın, statların güçlendi!\n")

    elif sec == "2":
        print("\n🗡️ Hangi antrenmanı yapacaksın?")
        print("1) Çabukluk çalış (+1 şans)")
        print("2) Kısa taktik çalışması (+1 zeka)")
        print("3) Konsantrasyon egzersizi (+1 karizma)")
        print("4) Hafif fiziksel antrenman (+1 güç)")
        ant = input("\nSeçimin: ")
        if ant == "1": apply_buff(character, "şans", 1)
        elif ant == "2": apply_buff(character, "zeka", 1)
        elif ant == "3": apply_buff(character, "karizma", 1)
        elif ant == "4": apply_buff(character, "güç", 1)
        print("💪 Antrenman tamamlandı. Kendini daha iyi hissediyorsun.\n")

    elif sec == "3":
        print("\n🍃 Ormanda hafif bir rüzgar eser…")
        rast = random.choice(["şans", "zeka", "karizma", "güç"])
        apply_buff(character, rast, 1)
        print(f"Doğa seni güçlendirdi → +1 {rast}\n")

    else:
        print("Menüye dönülüyor...\n")


def main():
    character = create_character()

    while True:
        print("\n--- ANA MENÜ ---")
        print("1) Karakter bilgilerini görüntüle")
        print("2) Serbest zaman aktiviteleri")
        print("3) Sıradaki görevi al")
        print("4) Envanteri görüntüle")
        print("5) Çıkış")

        sec = input("\nSeçimin: ")

        if sec == "1":
            print_character(character)

        elif sec == "2":
            free_time_menu(character)

        elif sec == "3":
            quest = get_next_quest(character)
            if quest is None:
                print("Bu sınıf için başka görev kalmadı.")
            else:
                play_prelude(character, quest)

                try:
                    if has_choice_tree(character):
                        result = play_choice_tree(character, quest["task"])
                    else:
                        result = play_quest(character, quest["task"])
                except Exception as e:
                    print(f"(Choice tree'de hata oldu, klasik sisteme geçiyorum) Detay: {e}")
                    result = play_quest(character, quest["task"])

                # 🔽 ÖDÜL BURADA
                reward = quest.get("reward")
                if reward:
                    character["envanter"].append(reward)
                    print(f"\n🎁 Görev ödülü kazandın: {reward}")
                else:
                    print("\nBu görevde somut bir eşya kazanmadın, ama deneyim kazandın.")


                if result and result != "basarisiz":
                    if reward:
                        add_item(character, reward)
                        print(f"Bu gorevden sonra yaninda '{reward}' tasidigini fark ediyorsun.\n")

        elif sec == "4":
            print_inventory(character)

        elif sec == "5":
            print("\n🌿 Yollar açık olsun gezgin. Görüşmek üzere!")
            break

        else:
            print("Geçersiz seçim, tekrar dene.\n")


if __name__ == "__main__":
    main()
